<?php 

$pt_head = (get_option('wpp_T_logo')) ? '<img src="'. trim( get_option('wpp_T_logo') ) .'" />' : '';
$pt_head .= '<div style="text-align:center"><img src="'.WPP_PATH.'img/logo-top.png" /></div>';
$pt_head .= "<br>\r\n<br>\r\n";

?>
