<?php 

$header_text = '<img src="'. trim( get_option('wpp_T_logo') ) .'" />';
$header_text .= '<div style="text-align:center !important;"><img src="'.WPP_PATH.'img/logo-top.png" /></div>';
$header_text .= "<br>\r\n<br>\r\n";

$STR['head'] = $header_text ;
?>
