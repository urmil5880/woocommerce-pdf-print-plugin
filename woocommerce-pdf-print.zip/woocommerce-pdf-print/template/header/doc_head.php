<?php 
$doc_head = "<br>";
$doc_head .= (get_option('wpp_T_logo')) ? '<img src="'. trim( get_option('wpp_T_logo') ) .'" />' : '';
$doc_head .= "<br>";
$doc_head .= '<img src="'.WPP_PATH.'img/line-doc.png" width="750px" />';
$doc_head .= "<br>";

?>