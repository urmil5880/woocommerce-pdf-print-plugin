<?php
$name='DejaVuSerifCondensed-Italic';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 68,
  'FontBBox' => '[-755 -347 1480 1109]',
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='/home/jeffcoop/public_html/cms/cms2016/wp-content/plugins/woocommerce-pdf-print/tpdf/font/unifont/DejaVuSerifCondensed-Italic.ttf';
$originalsize=338140;
$fontkey='dejavuI';
?>